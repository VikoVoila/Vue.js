import firebase from 'firebase'
import firestore from 'firebase/firestore'
// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyCcn6o-tZqpp_QaaDv-LcCwYwL-z7qlFLM",
    authDomain: "udemy-voila-smoothie.firebaseapp.com",
    databaseURL: "https://udemy-voila-smoothie.firebaseio.com",
    projectId: "udemy-voila-smoothie",
    storageBucket: "udemy-voila-smoothie.appspot.com",
    messagingSenderId: "579562031943",
    appId: "1:579562031943:web:c63902bf270de6ed2a1a62",
    measurementId: "G-MZ121FXMQM"
  };
  // Initialize Firebase
  const firebaseApp = firebase.initializeApp(firebaseConfig);
  // firebaseApp.firestore().settings({ timestampsInSnapshots: true })
  firebase.analytics();

  export default firebaseApp.firestore()