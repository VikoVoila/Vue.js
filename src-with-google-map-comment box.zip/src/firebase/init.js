import firebase from 'firebase'
import firestore from 'firebase/firestore'

// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyD6VRrDBucB74SI0xmTL7ldMx7GrHgq3uU",
    authDomain: "geo-voila.firebaseapp.com",
    databaseURL: "https://geo-voila.firebaseio.com",
    projectId: "geo-voila",
    storageBucket: "geo-voila.appspot.com",
    messagingSenderId: "1026299283978",
    appId: "1:1026299283978:web:cc2b315ebe869ea90badf3",
    measurementId: "G-EP0JSRPRRC"
  };
  // Initialize Firebase
  const firebaseApp = firebase.initializeApp(firebaseConfig);
  firebase.analytics(); 

  export default firebaseApp.firestore()